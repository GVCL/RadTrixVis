import './App.css';
import React from 'react';
import RadTrix from './RadTrix';
import { Col, Radio, Row, Select, Transfer, Typography } from 'antd';
import { getIndex } from './helpers';
import { data } from './data';
import { useRecoilState, useSetRecoilState } from 'recoil';
import { currentIndexAtom, dataAtom, edgeTypeAtom, orderTypeAtom } from './state';
import { cloneDeep, range } from 'lodash';

function App() {
    const options = Object.keys(getIndex).map(e => {
        return {
            label: e,
            value: getIndex[e]
        }
    });
    const transferData = data.circlenodes.map((e, i) => {
        return {
            key: e.name,
            title: e.name,
            chosen: 0
        }
    })
    const [selOpt, setSelOpt] = React.useState(range(options.length));
    const [selTransfer, setSelTransfer] = React.useState(data.circlenodes.map(e => e.name));
    const setData = useSetRecoilState(dataAtom);
    const setCurrentIndex = useSetRecoilState(currentIndexAtom);
    const [edgeType, setEdgeType] = useRecoilState(edgeTypeAtom);
    const [orderType, setOrderType] = useRecoilState(orderTypeAtom);

    React.useEffect(() => {
        const newData = cloneDeep(data);

        // Handling the changes to the Square Nodes
        newData.nodes = newData.nodes.filter(e => selOpt.findIndex(f => f === e.index) !== -1);
        newData.links = newData.links.filter(e => (selOpt.findIndex(f => f === e.source) !== -1) && (selOpt.findIndex(f => f === e.target) !== -1));
        const selNames = selOpt.map(e => Object.keys(getIndex).find(f => getIndex[f] === e));
        newData.circleedges = newData.circleedges.filter(e => selNames.findIndex(f => f === e.target) !== -1);
        const indexMap = {};
        const currentIndex = {};
        newData.nodes.forEach((e, i) => {
            indexMap[e.index] = i;
            e.index = i;
            currentIndex[e.name] = e.index;
        })
        newData.links.forEach(e => {
            e.source = indexMap[e.source];
            e.target = indexMap[e.target];
        });

        // Handling Changes to Circle Nodes
        newData.circlenodes = newData.circlenodes.filter(e => selTransfer.findIndex(f => f === e.name) !== -1);
        newData.circleedges = newData.circleedges.filter(e => selTransfer.findIndex(f => f === e.source) !== -1);

        console.log(newData)

        setData(newData);
        setCurrentIndex(currentIndex);
    }, [selOpt, selTransfer, setData, setCurrentIndex]);

    return (
        <div className="App">
            <Row style={{textAlign: 'left'}}>
                <Col span={9}>
                    <Typography>Cancer Type: </Typography>
                    <Select
                        mode='tags'
                        size='default'
                        placeholder="Please select"
                        options={options}
                        value={selOpt}
                        onChange={e => (e.length > 0) ? setSelOpt([...e]): null}
                        style={{width: '75%'}}
                    />
                    <Typography>Cancer Genes:</Typography>
                    <Transfer 
                        dataSource={transferData}
                        showSearch
                        render={item => item.title}
                        listStyle={{width: '35%', height: 400}}
                        targetKeys={selTransfer}
                        onChange={e => e.length >= 4 ? setSelTransfer([...e]) : alert('Ensure atleast 4 genes in the pool.')}
                        titles={['Hidden', 'Shown']}
                        filterOption={(i, o) => o.title.toUpperCase().indexOf(i.toUpperCase()) > -1}
                    />
                    <Typography>Edge Type:</Typography>
                    <Radio.Group onChange={e => setEdgeType(e.target.value)} value={edgeType}>
                        <Radio value={1}>Straight Edges</Radio>
                        <Radio value={2}>Curved Edges</Radio>
                    </Radio.Group>
                    {edgeType === 2 ? 
                        <Radio.Group onChange={e => setOrderType(e.target.value)} value={orderType}>
                            <Radio value={1}>Barycentric ordering</Radio>
                            <Radio value={2}>Increasing order of degree</Radio>
                            <Radio value={3}>Random order</Radio>
                        </Radio.Group>
                        : <Radio.Group onChange={e => setOrderType(e.target.value)} value={orderType === 3 ? 1 : orderType}>
                            <Radio value={1}>Increasing order of degree</Radio>
                            <Radio value={2}>Random order</Radio>
                        </Radio.Group>
                    }
                </Col>
                <Col flex={15} >  
                    <RadTrix />
                </Col>
                
            </Row>
        </div>
    );
}

export default App;
